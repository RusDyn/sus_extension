!function(e){var t;"function"==typeof e&&(t=e,e=null),function(t,r,o,a,n){var s="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},i="function"==typeof s[a]&&s[a],l=i.cache||{},p="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function m(e,r){if(!l[e]){if(!t[e]){var o="function"==typeof s[a]&&s[a];if(!r&&o)return o(e,!0);if(i)return i(e,!0);if(p&&"string"==typeof e)return p(e);var n=Error("Cannot find module '"+e+"'");throw n.code="MODULE_NOT_FOUND",n}u.resolve=function(r){var o=t[e][1][r];return null!=o?o:r},u.cache={};var c=l[e]=new m.Module(e);t[e][0].call(c.exports,u,c,c.exports,this)}return l[e].exports;function u(e){var t=u.resolve(e);return!1===t?{}:m(t)}}m.isParcelRequire=!0,m.Module=function(e){this.id=e,this.bundle=m,this.exports={}},m.modules=t,m.cache=l,m.parent=i,m.register=function(e,r){t[e]=[function(e,t){t.exports=r},{}]},Object.defineProperty(m,"root",{get:function(){return s[a]}}),s[a]=m;for(var c=0;c<r.length;c++)m(r[c]);if(o){var u=m(o);"object"==typeof exports&&"undefined"!=typeof module?module.exports=u:"function"==typeof e&&e.amd?e(function(){return u}):n&&(this[n]=u)}}({aaoqk:[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"VectorDBQAChain",()=>s);var a=e("./base.js"),n=e("./question_answering/load.js");class s extends a.BaseChain{get inputKeys(){return[this.inputKey]}get outputKeys(){return this.combineDocumentsChain.outputKeys.concat(this.returnSourceDocuments?["sourceDocuments"]:[])}constructor(e){super(e),Object.defineProperty(this,"k",{enumerable:!0,configurable:!0,writable:!0,value:4}),Object.defineProperty(this,"inputKey",{enumerable:!0,configurable:!0,writable:!0,value:"query"}),Object.defineProperty(this,"vectorstore",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"combineDocumentsChain",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"returnSourceDocuments",{enumerable:!0,configurable:!0,writable:!0,value:!1}),this.vectorstore=e.vectorstore,this.combineDocumentsChain=e.combineDocumentsChain,this.inputKey=e.inputKey??this.inputKey,this.k=e.k??this.k,this.returnSourceDocuments=e.returnSourceDocuments??this.returnSourceDocuments}async _call(e,t){if(!(this.inputKey in e))throw Error(`Question key ${this.inputKey} not found.`);let r=e[this.inputKey],o=await this.vectorstore.similaritySearch(r,this.k,e.filter,t?.getChild("vectorstore")),a=await this.combineDocumentsChain.call({question:r,input_documents:o},t?.getChild("combine_documents"));return this.returnSourceDocuments?{...a,sourceDocuments:o}:a}_chainType(){return"vector_db_qa"}static async deserialize(e,t){if(!("vectorstore"in t))throw Error("Need to pass in a vectorstore to deserialize VectorDBQAChain");let{vectorstore:r}=t;if(!e.combine_documents_chain)throw Error("VectorDBQAChain must have combine_documents_chain in serialized data");return new s({combineDocumentsChain:await (0,a.BaseChain).deserialize(e.combine_documents_chain),k:e.k,vectorstore:r})}serialize(){return{_type:this._chainType(),combine_documents_chain:this.combineDocumentsChain.serialize(),k:this.k}}static fromLLM(e,t,r){let o=(0,n.loadQAStuffChain)(e);return new this({vectorstore:t,combineDocumentsChain:o,...r})}}},{"./base.js":"lIMAG","./question_answering/load.js":"7YIxP","@parcel/transformer-js/src/esmodule-helpers.js":"3Un90"}],"7YIxP":[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"loadQAChain",()=>p),o.export(r,"loadQAStuffChain",()=>m),o.export(r,"loadQAMapReduceChain",()=>c),o.export(r,"loadQARefineChain",()=>u);var a=e("../llm_chain.js"),n=e("../combine_docs_chain.js"),s=e("./stuff_prompts.js"),i=e("./map_reduce_prompts.js"),l=e("./refine_prompts.js");let p=(e,t={type:"stuff"})=>{let{type:r}=t;if("stuff"===r)return m(e,t);if("map_reduce"===r)return c(e,t);if("refine"===r)return u(e,t);throw Error(`Invalid _type: ${r}`)};function m(e,t={}){let{prompt:r=(0,s.QA_PROMPT_SELECTOR).getPrompt(e),verbose:o}=t,i=new a.LLMChain({prompt:r,llm:e,verbose:o}),l=new n.StuffDocumentsChain({llmChain:i,verbose:o});return l}function c(e,t={}){let{combineMapPrompt:r=(0,i.COMBINE_QA_PROMPT_SELECTOR).getPrompt(e),combinePrompt:o=(0,i.COMBINE_PROMPT_SELECTOR).getPrompt(e),verbose:s,returnIntermediateSteps:l}=t,p=new a.LLMChain({prompt:r,llm:e,verbose:s}),m=new a.LLMChain({prompt:o,llm:e,verbose:s}),c=new n.StuffDocumentsChain({llmChain:m,documentVariableName:"summaries",verbose:s}),u=new n.MapReduceDocumentsChain({llmChain:p,combineDocumentChain:c,returnIntermediateSteps:l,verbose:s});return u}function u(e,t={}){let{questionPrompt:r=(0,l.QUESTION_PROMPT_SELECTOR).getPrompt(e),refinePrompt:o=(0,l.REFINE_PROMPT_SELECTOR).getPrompt(e),verbose:s}=t,i=new a.LLMChain({prompt:r,llm:e,verbose:s}),p=new a.LLMChain({prompt:o,llm:e,verbose:s}),m=new n.RefineDocumentsChain({llmChain:i,refineLLMChain:p,verbose:s});return m}},{"../llm_chain.js":"eAdUv","../combine_docs_chain.js":"1t8hB","./stuff_prompts.js":"5RvhE","./map_reduce_prompts.js":"lqNcC","./refine_prompts.js":"93rEB","@parcel/transformer-js/src/esmodule-helpers.js":"3Un90"}],"5RvhE":[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"DEFAULT_QA_PROMPT",()=>i),o.export(r,"QA_PROMPT_SELECTOR",()=>c);var a=e("../../prompts/prompt.js"),n=e("../../prompts/chat.js"),s=e("../../prompts/selectors/conditional.js");let i=new a.PromptTemplate({template:"Use the following pieces of context to answer the question at the end. If you don't know the answer, just say that you don't know, don't try to make up an answer.\n\n{context}\n\nQuestion: {question}\nHelpful Answer:",inputVariables:["context","question"]}),l=`Use the following pieces of context to answer the users question. 
If you don't know the answer, just say that you don't know, don't try to make up an answer.
----------------
{context}`,p=[(0,n.SystemMessagePromptTemplate).fromTemplate(l),(0,n.HumanMessagePromptTemplate).fromTemplate("{question}")],m=(0,n.ChatPromptTemplate).fromPromptMessages(p),c=new s.ConditionalPromptSelector(i,[[s.isChatModel,m]])},{"../../prompts/prompt.js":"8xLhj","../../prompts/chat.js":"7lFtF","../../prompts/selectors/conditional.js":"h8jrf","@parcel/transformer-js/src/esmodule-helpers.js":"3Un90"}],h8jrf:[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"BasePromptSelector",()=>a),o.export(r,"ConditionalPromptSelector",()=>n),o.export(r,"isLLM",()=>s),o.export(r,"isChatModel",()=>i);class a{async getPromptAsync(e,t){let r=this.getPrompt(e);return r.partial(t?.partialVariables??{})}}class n extends a{constructor(e,t=[]){super(),Object.defineProperty(this,"defaultPrompt",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"conditionals",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.defaultPrompt=e,this.conditionals=t}getPrompt(e){for(let[t,r]of this.conditionals)if(t(e))return r;return this.defaultPrompt}}function s(e){return"base_llm"===e._modelType()}function i(e){return"base_chat_model"===e._modelType()}},{"@parcel/transformer-js/src/esmodule-helpers.js":"3Un90"}],lqNcC:[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"DEFAULT_COMBINE_QA_PROMPT",()=>l),o.export(r,"COMBINE_QA_PROMPT_SELECTOR",()=>u),o.export(r,"COMBINE_PROMPT",()=>d),o.export(r,"COMBINE_PROMPT_SELECTOR",()=>y);var a=e("../../prompts/prompt.js"),n=e("../../prompts/chat.js"),s=e("../../prompts/selectors/conditional.js");let i=`Use the following portion of a long document to see if any of the text is relevant to answer the question. 
Return any relevant text verbatim.
{context}
Question: {question}
Relevant text, if any:`,l=(0,a.PromptTemplate).fromTemplate(i),p=`Use the following portion of a long document to see if any of the text is relevant to answer the question. 
Return any relevant text verbatim.
----------------
{context}`,m=[(0,n.SystemMessagePromptTemplate).fromTemplate(p),(0,n.HumanMessagePromptTemplate).fromTemplate("{question}")],c=(0,n.ChatPromptTemplate).fromPromptMessages(m),u=new s.ConditionalPromptSelector(l,[[s.isChatModel,c]]),h=`Given the following extracted parts of a long document and a question, create a final answer. 
If you don't know the answer, just say that you don't know. Don't try to make up an answer.

QUESTION: Which state/country's law governs the interpretation of the contract?
=========
Content: This Agreement is governed by English law and the parties submit to the exclusive jurisdiction of the English courts in  relation to any dispute (contractual or non-contractual) concerning this Agreement save that either party may apply to any court for an  injunction or other relief to protect its Intellectual Property Rights.

Content: No Waiver. Failure or delay in exercising any right or remedy under this Agreement shall not constitute a waiver of such (or any other)  right or remedy.

11.7 Severability. The invalidity, illegality or unenforceability of any term (or part of a term) of this Agreement shall not affect the continuation  in force of the remainder of the term (if any) and this Agreement.

11.8 No Agency. Except as expressly stated otherwise, nothing in this Agreement shall create an agency, partnership or joint venture of any  kind between the parties.

11.9 No Third-Party Beneficiaries.

Content: (b) if Google believes, in good faith, that the Distributor has violated or caused Google to violate any Anti-Bribery Laws (as  defined in Clause 8.5) or that such a violation is reasonably likely to occur,
=========
FINAL ANSWER: This Agreement is governed by English law.

QUESTION: What did the president say about Michael Jackson?
=========
Content: Madam Speaker, Madam Vice President, our First Lady and Second Gentleman. Members of Congress and the Cabinet. Justices of the Supreme Court. My fellow Americans.  

Last year COVID-19 kept us apart. This year we are finally together again. 

Tonight, we meet as Democrats Republicans and Independents. But most importantly as Americans. 

With a duty to one another to the American people to the Constitution. 

And with an unwavering resolve that freedom will always triumph over tyranny. 

Six days ago, Russia\u2019s Vladimir Putin sought to shake the foundations of the free world thinking he could make it bend to his menacing ways. But he badly miscalculated. 

He thought he could roll into Ukraine and the world would roll over. Instead he met a wall of strength he never imagined. 

He met the Ukrainian people. 

From President Zelenskyy to every Ukrainian, their fearlessness, their courage, their determination, inspires the world. 

Groups of citizens blocking tanks with their bodies. Everyone from students to retirees teachers turned soldiers defending their homeland.

Content: And we won\u2019t stop. 

We have lost so much to COVID-19. Time with one another. And worst of all, so much loss of life. 

Let\u2019s use this moment to reset. Let\u2019s stop looking at COVID-19 as a partisan dividing line and see it for what it is: A God-awful disease.  

Let\u2019s stop seeing each other as enemies, and start seeing each other for who we really are: Fellow Americans.  

We can\u2019t change how divided we\u2019ve been. But we can change how we move forward\u2014on COVID-19 and other issues we must face together. 

I recently visited the New York City Police Department days after the funerals of Officer Wilbert Mora and his partner, Officer Jason Rivera. 

They were responding to a 9-1-1 call when a man shot and killed them with a stolen gun. 

Officer Mora was 27 years old. 

Officer Rivera was 22. 

Both Dominican Americans who\u2019d grown up on the same streets they later chose to patrol as police officers. 

I spoke with their families and told them that we are forever in debt for their sacrifice, and we will carry on their mission to restore the trust and safety every community deserves.

Content: And a proud Ukrainian people, who have known 30 years  of independence, have repeatedly shown that they will not tolerate anyone who tries to take their country backwards.  

To all Americans, I will be honest with you, as I\u2019ve always promised. A Russian dictator, invading a foreign country, has costs around the world. 

And I\u2019m taking robust action to make sure the pain of our sanctions  is targeted at Russia\u2019s economy. And I will use every tool at our disposal to protect American businesses and consumers. 

Tonight, I can announce that the United States has worked with 30 other countries to release 60 Million barrels of oil from reserves around the world.  

America will lead that effort, releasing 30 Million barrels from our own Strategic Petroleum Reserve. And we stand ready to do more if necessary, unified with our allies.  

These steps will help blunt gas prices here at home. And I know the news about what\u2019s happening can seem alarming. 

But I want you to know that we are going to be okay.

Content: More support for patients and families. 

To get there, I call on Congress to fund ARPA-H, the Advanced Research Projects Agency for Health. 

It\u2019s based on DARPA\u2014the Defense Department project that led to the Internet, GPS, and so much more.  

ARPA-H will have a singular purpose\u2014to drive breakthroughs in cancer, Alzheimer\u2019s, diabetes, and more. 

A unity agenda for the nation. 

We can do this. 

My fellow Americans\u2014tonight , we have gathered in a sacred space\u2014the citadel of our democracy. 

In this Capitol, generation after generation, Americans have debated great questions amid great strife, and have done great things. 

We have fought for freedom, expanded liberty, defeated totalitarianism and terror. 

And built the strongest, freest, and most prosperous nation the world has ever known. 

Now is the hour. 

Our moment of responsibility. 

Our test of resolve and conscience, of history itself. 

It is in this moment that our character is formed. Our purpose is found. Our future is forged. 

Well I know this nation.
=========
FINAL ANSWER: The president did not mention Michael Jackson.

QUESTION: {question}
=========
{summaries}
=========
FINAL ANSWER:`,d=(0,a.PromptTemplate).fromTemplate(h),f=`Given the following extracted parts of a long document and a question, create a final answer. 
If you don't know the answer, just say that you don't know. Don't try to make up an answer.
----------------
{summaries}`,g=[(0,n.SystemMessagePromptTemplate).fromTemplate(f),(0,n.HumanMessagePromptTemplate).fromTemplate("{question}")],w=(0,n.ChatPromptTemplate).fromPromptMessages(g),y=new s.ConditionalPromptSelector(d,[[s.isChatModel,w]])},{"../../prompts/prompt.js":"8xLhj","../../prompts/chat.js":"7lFtF","../../prompts/selectors/conditional.js":"h8jrf","@parcel/transformer-js/src/esmodule-helpers.js":"3Un90"}],"93rEB":[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"DEFAULT_REFINE_PROMPT_TMPL",()=>s),o.export(r,"DEFAULT_REFINE_PROMPT",()=>i),o.export(r,"CHAT_REFINE_PROMPT",()=>m),o.export(r,"REFINE_PROMPT_SELECTOR",()=>c),o.export(r,"DEFAULT_TEXT_QA_PROMPT_TMPL",()=>u),o.export(r,"DEFAULT_TEXT_QA_PROMPT",()=>h),o.export(r,"CHAT_QUESTION_PROMPT",()=>g),o.export(r,"QUESTION_PROMPT_SELECTOR",()=>w);var a=e("../../prompts/index.js"),n=e("../../prompts/selectors/conditional.js");let s=`The original question is as follows: {question}
We have provided an existing answer: {existing_answer}
We have the opportunity to refine the existing answer
(only if needed) with some more context below.
------------
{context}
------------
Given the new context, refine the original answer to better answer the question. 
If the context isn't useful, return the original answer.`,i=new a.PromptTemplate({inputVariables:["question","existing_answer","context"],template:s}),l=`The original question is as follows: {question}
We have provided an existing answer: {existing_answer}
We have the opportunity to refine the existing answer
(only if needed) with some more context below.
------------
{context}
------------
Given the new context, refine the original answer to better answer the question. 
If the context isn't useful, return the original answer.`,p=[(0,a.HumanMessagePromptTemplate).fromTemplate("{question}"),(0,a.AIMessagePromptTemplate).fromTemplate("{existing_answer}"),(0,a.HumanMessagePromptTemplate).fromTemplate(l)],m=(0,a.ChatPromptTemplate).fromPromptMessages(p),c=new n.ConditionalPromptSelector(i,[[n.isChatModel,m]]),u=`Context information is below. 
---------------------
{context}
---------------------
Given the context information and not prior knowledge, answer the question: {question}`,h=new a.PromptTemplate({inputVariables:["context","question"],template:u}),d=`Context information is below. 
---------------------
{context}
---------------------
Given the context information and not prior knowledge, answer any questions`,f=[(0,a.SystemMessagePromptTemplate).fromTemplate(d),(0,a.HumanMessagePromptTemplate).fromTemplate("{question}")],g=(0,a.ChatPromptTemplate).fromPromptMessages(f),w=new n.ConditionalPromptSelector(h,[[n.isChatModel,g]])},{"../../prompts/index.js":"bHOGP","../../prompts/selectors/conditional.js":"h8jrf","@parcel/transformer-js/src/esmodule-helpers.js":"3Un90"}],bHOGP:[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"BaseExampleSelector",()=>a.BaseExampleSelector),o.export(r,"BasePromptTemplate",()=>a.BasePromptTemplate),o.export(r,"StringPromptValue",()=>a.StringPromptValue),o.export(r,"BaseStringPromptTemplate",()=>a.BaseStringPromptTemplate),o.export(r,"PromptTemplate",()=>n.PromptTemplate),o.export(r,"BasePromptSelector",()=>s.BasePromptSelector),o.export(r,"ConditionalPromptSelector",()=>s.ConditionalPromptSelector),o.export(r,"isChatModel",()=>s.isChatModel),o.export(r,"isLLM",()=>s.isLLM),o.export(r,"LengthBasedExampleSelector",()=>i.LengthBasedExampleSelector),o.export(r,"SemanticSimilarityExampleSelector",()=>l.SemanticSimilarityExampleSelector),o.export(r,"FewShotPromptTemplate",()=>p.FewShotPromptTemplate),o.export(r,"ChatPromptTemplate",()=>m.ChatPromptTemplate),o.export(r,"HumanMessagePromptTemplate",()=>m.HumanMessagePromptTemplate),o.export(r,"AIMessagePromptTemplate",()=>m.AIMessagePromptTemplate),o.export(r,"SystemMessagePromptTemplate",()=>m.SystemMessagePromptTemplate),o.export(r,"ChatMessagePromptTemplate",()=>m.ChatMessagePromptTemplate),o.export(r,"MessagesPlaceholder",()=>m.MessagesPlaceholder),o.export(r,"BaseChatPromptTemplate",()=>m.BaseChatPromptTemplate),o.export(r,"parseTemplate",()=>c.parseTemplate),o.export(r,"renderTemplate",()=>c.renderTemplate),o.export(r,"checkValidTemplate",()=>c.checkValidTemplate),o.export(r,"PipelinePromptTemplate",()=>u.PipelinePromptTemplate);var a=e("./base.js"),n=e("./prompt.js"),s=e("./selectors/conditional.js"),i=e("./selectors/LengthBasedExampleSelector.js"),l=e("./selectors/SemanticSimilarityExampleSelector.js"),p=e("./few_shot.js"),m=e("./chat.js"),c=e("./template.js"),u=e("./pipeline.js")},{"./base.js":"gn6sY","./prompt.js":"8xLhj","./selectors/conditional.js":"h8jrf","./selectors/LengthBasedExampleSelector.js":"79Ted","./selectors/SemanticSimilarityExampleSelector.js":"cKFMf","./few_shot.js":"5ITLG","./chat.js":"7lFtF","./template.js":"cBC5u","./pipeline.js":"6UKRI","@parcel/transformer-js/src/esmodule-helpers.js":"3Un90"}],"79Ted":[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"LengthBasedExampleSelector",()=>s);var a=e("../base.js");function n(e){return e.split(/\n| /).length}class s extends a.BaseExampleSelector{constructor(e){super(e),Object.defineProperty(this,"examples",{enumerable:!0,configurable:!0,writable:!0,value:[]}),Object.defineProperty(this,"examplePrompt",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"getTextLength",{enumerable:!0,configurable:!0,writable:!0,value:n}),Object.defineProperty(this,"maxLength",{enumerable:!0,configurable:!0,writable:!0,value:2048}),Object.defineProperty(this,"exampleTextLengths",{enumerable:!0,configurable:!0,writable:!0,value:[]}),this.examplePrompt=e.examplePrompt,this.maxLength=e.maxLength??2048,this.getTextLength=e.getTextLength??n}async addExample(e){this.examples.push(e);let t=await this.examplePrompt.format(e);this.exampleTextLengths.push(this.getTextLength(t))}async calculateExampleTextLengths(e,t){if(e.length>0)return e;let{examples:r,examplePrompt:o}=t,a=await Promise.all(r.map(e=>o.format(e)));return a.map(e=>this.getTextLength(e))}async selectExamples(e){let t=Object.values(e).join(" "),r=this.maxLength-this.getTextLength(t),o=0,a=[];for(;r>0&&o<this.examples.length;){let e=r-this.exampleTextLengths[o];if(e<0)break;a.push(this.examples[o]),r=e,o+=1}return a}static async fromExamples(e,t){let r=new s(t);return await Promise.all(e.map(e=>r.addExample(e))),r}}},{"../base.js":"gn6sY","@parcel/transformer-js/src/esmodule-helpers.js":"3Un90"}],cKFMf:[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"SemanticSimilarityExampleSelector",()=>i);var a=e("../../document.js"),n=e("../base.js");function s(e){return Object.keys(e).sort().map(t=>e[t])}class i extends n.BaseExampleSelector{constructor(e){super(e),Object.defineProperty(this,"vectorStore",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"k",{enumerable:!0,configurable:!0,writable:!0,value:4}),Object.defineProperty(this,"exampleKeys",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"inputKeys",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.vectorStore=e.vectorStore,this.k=e.k??4,this.exampleKeys=e.exampleKeys,this.inputKeys=e.inputKeys}async addExample(e){let t=this.inputKeys??Object.keys(e),r=s(t.reduce((t,r)=>({...t,[r]:e[r]}),{})).join(" ");await this.vectorStore.addDocuments([new a.Document({pageContent:r,metadata:{example:e}})])}async selectExamples(e){let t=this.inputKeys??Object.keys(e),r=s(t.reduce((t,r)=>({...t,[r]:e[r]}),{})).join(" "),o=await this.vectorStore.similaritySearch(r,this.k),a=o.map(e=>e.metadata);return this.exampleKeys?a.map(e=>this.exampleKeys.reduce((t,r)=>({...t,[r]:e[r]}),{})):a}static async fromExamples(e,t,r,o={}){let a=o.inputKeys??null,n=e.map(e=>s(a?a.reduce((t,r)=>({...t,[r]:e[r]}),{}):e).join(" ")),l=await r.fromTexts(n,e,t,o);return new i({vectorStore:l,k:o.k??4,exampleKeys:o.exampleKeys,inputKeys:o.inputKeys})}}},{"../../document.js":"eH5AU","../base.js":"gn6sY","@parcel/transformer-js/src/esmodule-helpers.js":"3Un90"}],eH5AU:[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"Document",()=>a);class a{constructor(e){Object.defineProperty(this,"pageContent",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"metadata",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.pageContent=e.pageContent?e.pageContent.toString():this.pageContent,this.metadata=e.metadata??{}}}},{"@parcel/transformer-js/src/esmodule-helpers.js":"3Un90"}],"6UKRI":[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"PipelinePromptTemplate",()=>s);var a=e("./base.js"),n=e("./chat.js");class s extends a.BasePromptTemplate{constructor(e){super({...e,inputVariables:[]}),Object.defineProperty(this,"pipelinePrompts",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"finalPrompt",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.pipelinePrompts=e.pipelinePrompts,this.finalPrompt=e.finalPrompt,this.inputVariables=this.computeInputValues()}computeInputValues(){let e=this.pipelinePrompts.map(e=>e.name),t=this.pipelinePrompts.map(t=>t.prompt.inputVariables.filter(t=>!e.includes(t))).flat();return[...new Set(t)]}static extractRequiredInputValues(e,t){return t.reduce((t,r)=>(t[r]=e[r],t),{})}async formatPipelinePrompts(e){let t=await this.mergePartialAndUserVariables(e);for(let{name:e,prompt:r}of this.pipelinePrompts){let o=s.extractRequiredInputValues(t,r.inputVariables);r instanceof n.ChatPromptTemplate?t[e]=await r.formatMessages(o):t[e]=await r.format(o)}return s.extractRequiredInputValues(t,this.finalPrompt.inputVariables)}async formatPromptValue(e){return this.finalPrompt.formatPromptValue(await this.formatPipelinePrompts(e))}async format(e){return this.finalPrompt.format(await this.formatPipelinePrompts(e))}async partial(e){let t={...this};return t.inputVariables=this.inputVariables.filter(t=>!(t in e)),t.partialVariables={...this.partialVariables??{},...e},new s(t)}serialize(){throw Error("Not implemented.")}_getPromptType(){return"pipeline"}}},{"./base.js":"gn6sY","./chat.js":"7lFtF","@parcel/transformer-js/src/esmodule-helpers.js":"3Un90"}]},[],null,"parcelRequire2f2e"),globalThis.define=t}(globalThis.define);